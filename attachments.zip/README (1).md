# MusicWebApplication
This application streams music online from firebase storage and firebase firestore.This application is hosted using Firebase Hosting https://webproject-ab93a.firebaseapp.com/ .Developed using Javascript,HTML and CSS.
It has options to search for songs,create playlist and stream songs online.It also has suggestion to play songs from same artist options.It was done only for understanding purposes and hence contains only 40songs to play online
APIs used- Firebase Storage(to store songs),Firebase Firestore(to store metadata of the songs in the Firebase Storage) and Firebase Authentication(to maintain user session,store authentication information,send verification mail and validate login and logouts more effeciently).
